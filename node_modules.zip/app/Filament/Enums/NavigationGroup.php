<?php

namespace App\Filament\Enums;

enum NavigationGroup: string
{
    case Content = 'Content';
    case Messages = 'Messages';
}
