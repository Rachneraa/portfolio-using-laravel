<?php

namespace App\Filament\Resources\Sekolahs\Pages;

use App\Filament\Resources\Sekolahs\SekolahResource;
use Filament\Resources\Pages\CreateRecord;

class CreateSekolah extends CreateRecord
{
    protected static string $resource = SekolahResource::class;
}
